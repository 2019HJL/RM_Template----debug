#ifndef SYSTEM_RESET_H_INCLUDED
#define SYSTEM_RESET_H_INCLUDED

#include "sys.h"

void System_Reset();			//��������λ


#endif // SYSTEM_RESET_H_INCUDED
