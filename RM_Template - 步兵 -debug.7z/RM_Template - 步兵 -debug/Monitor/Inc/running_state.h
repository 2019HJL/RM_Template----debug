#ifndef RUNNING_STATE_H_INCLUDED
#define RUNNING_STATE_H_INCLUDED

#include "sys.h"

void Running_State_Init(void)；						
void Running_State_Add( char *running_state_str)；
void Running_State_Report(void)；




#endif
