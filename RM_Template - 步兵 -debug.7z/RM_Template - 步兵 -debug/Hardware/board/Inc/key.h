#ifndef KEY_H_INCLUDED
#define KEY_H_INCLUDED

#include "sys.h"

#define KEY_PRESSED 	1			//����
#define KEY_UNPRESSED 	2			//�ɿ�

u8 KEY_Scan(void);


#endif // KEY_H_INCLUDED
