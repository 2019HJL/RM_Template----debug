#ifndef BEEP_H_INCLUDED
#define BEEP_H_INCLUDED

#include "sys.h"



void Beep_Init(void);		//Beep��ʼ��
void Beep_On(void);			//����Beep
void Beep_Off(void);		//�ر�Beep



#endif // BEEP_H_INCLUDED
