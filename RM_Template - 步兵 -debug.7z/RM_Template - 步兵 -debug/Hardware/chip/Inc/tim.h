#ifndef TIM_H_INCLUDED
#define TIM_H_INCLUDED

#include "sys.h"


void TIM6_Init(u32 time);



//extern u32 ramp_cnt;		//б�º���֧�ֱ��� 



#endif // TIM_H_INCLUDED
