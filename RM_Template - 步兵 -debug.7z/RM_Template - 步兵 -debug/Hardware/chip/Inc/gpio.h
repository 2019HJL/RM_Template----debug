#ifndef GPIO_H_INCLUDED
#define GPIO_H_INCLUDED


#include "sys.h"


void RM_GPIO_Init(void);



#endif // GPIO_H_INCLUDED
