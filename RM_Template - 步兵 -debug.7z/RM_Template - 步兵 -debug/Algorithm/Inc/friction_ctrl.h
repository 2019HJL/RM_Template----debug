#ifndef FRICTION_CTRL_H_INCLUDED
#define FRICTION_CTRL_H_INCLUDED

#include "sys.h"


void Friction_Ctrl( void);


#endif 

